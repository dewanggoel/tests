package com;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class MySessionListener implements HttpSessionListener{
	public void sessionCreated(HttpSessionEvent arg0) {
	//sc is application scope	
	ServletContext sc=arg0.getSession().getServletContext();
	  String sessionCount=(String)sc.getAttribute("sessionCount");
	  if(sessionCount==null){
		  sc.setAttribute("sessionCount", "1");
	  }else{
		 int newCount=Integer.parseInt(sessionCount)+1;
		 sc.setAttribute("sessionCount", newCount+"");
	  }
	}

	public void sessionDestroyed(HttpSessionEvent arg0) {
		
		//sc is application scope	
		ServletContext sc=arg0.getSession().getServletContext();
		 String sessionCount=(String)sc.getAttribute("sessionCount");
		  if(sessionCount==null){
		
		  }else{
			 int newCount=Integer.parseInt(sessionCount)-1;
			 sc.setAttribute("sessionCount", newCount+"");
		  }
		
	}

}
