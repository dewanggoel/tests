package com;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * 
 * @author nagendra.yadav.niit@gmail.com
 *
 */

public class ApplicationListener implements ServletContextListener {

    public void contextInitialized(ServletContextEvent arg0) {
    	ServletContext  sc=arg0.getServletContext();
    	sc.setAttribute("email", "nagendra.yadav.niit@gmail");
    	System.out.println("Application is started.........................");
	
    }
	public void contextDestroyed(ServletContextEvent arg0) {
	
		
	}
}
