package com;

/**
 * 
 * @author nagendra.yadav.niit@gmail.com
 *  Java Bean is simple class in which we can write our business logic.
 *  And we will use this in JSP.
 *
 */
public class LoginSessionBean {
	
	private String login;
	private String password;
	
	/**
	 *  @return String
	 *   getter for login.
	 */
	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	//Default constructor.
	public LoginSessionBean(){
		
	}
	
	/**
	 *  authenticating an User
	 * @return
	 */
	public boolean varifyUser(){
		
	    System.out.println("_______________INSIDE the verifyuser!______________-");
		if(login.equals("admin"))
			return true;
		else
			return false;
	}
}
